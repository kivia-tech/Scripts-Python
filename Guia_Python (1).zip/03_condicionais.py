# 03 - Estruturas Condicionais
# Usamos if, elif e else para tomar decisões.
idade = 18

if idade >= 18:
    print("Maior de idade")
elif idade == 17:
    print("Quase lá!")
else:
    print("Menor de idade")
