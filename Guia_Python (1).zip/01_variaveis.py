# 01 - Variáveis
# As variáveis armazenam valores para uso posterior.
nome = "Kivia"
idade = 24
altura = 1.60
ativa = True

print("Nome:", nome)
print("Idade:", idade)
print("Altura:", altura)
print("Ativa:", ativa)
