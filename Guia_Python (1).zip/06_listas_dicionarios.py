# 06 - Listas e Dicionários

# Lista (coleção ordenada)
frutas = ["maçã", "banana", "uva"]
frutas.append("abacaxi")  # adiciona item

print("Lista de frutas:", frutas)
print("Primeira fruta:", frutas[0])

# Dicionário (chave:valor)
pessoa = {
    "nome": "Kivia",
    "idade": 24,
    "cidade": "Belo Horizonte"
}
print("Nome da pessoa:", pessoa["nome"])
