# 04 - Estruturas de Repetição
# Repetição com for e while

# Exemplo com for
for i in range(5):
    print("Contando com for:", i)

# Exemplo com while
contador = 0
while contador < 3:
    print("Contando com while:", contador)
    contador += 1
