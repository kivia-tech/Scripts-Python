# 05 - Funções
# As funções agrupam instruções que podem ser reutilizadas.

def saudacao(nome):
    """Exemplo simples de função."""
    return f"Olá, {nome}! Seja bem-vinda."

print(saudacao("Kivia"))
