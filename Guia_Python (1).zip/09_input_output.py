# 09 - Entrada e Saída
# O comando input() lê dados do usuário.
# print() exibe informações na tela.

# nome_usuario = input("Digite seu nome: ")
# print("Olá,", nome_usuario)

print("Exemplo de entrada e saída (comentado para não travar o programa).")
